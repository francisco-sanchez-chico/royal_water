package com.app.royal.royal.entidades;

public enum MotivoMovimiento {
    REABASTECIMIENTO,
    DEFECTO,
    VENTA
}

