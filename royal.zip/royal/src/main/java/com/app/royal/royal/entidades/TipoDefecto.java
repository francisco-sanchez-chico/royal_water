package com.app.royal.royal.entidades;

public enum TipoDefecto {
    DANO_FISICO("Daño físico"),
    FUGA("Fuga"),
    MAL_ESTADO("Mal estado"),
    CADUCADO("Caducado");

    private final String nombreAmigable;

    TipoDefecto(String nombreAmigable) {
        this.nombreAmigable = nombreAmigable;
    }

    public String getNombreAmigable() {
        return nombreAmigable;
    }
}


