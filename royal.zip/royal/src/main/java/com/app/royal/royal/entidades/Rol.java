package com.app.royal.royal.entidades;

public enum Rol {
    ADMINISTRADOR,
    EMPLEADO
}

