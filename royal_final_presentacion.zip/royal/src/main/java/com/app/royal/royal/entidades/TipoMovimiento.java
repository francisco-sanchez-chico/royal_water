package com.app.royal.royal.entidades;

public enum TipoMovimiento {
    ENTRADA,
    SALIDA
}
