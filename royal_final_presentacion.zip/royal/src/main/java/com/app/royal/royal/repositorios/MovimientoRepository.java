package com.app.royal.royal.repositorios;

import com.app.royal.royal.entidades.MotivoMovimiento;
import com.app.royal.royal.entidades.Movimiento;
import com.app.royal.royal.entidades.TipoMovimiento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface MovimientoRepository extends JpaRepository<Movimiento, Long> {
    List<Movimiento> findByProductoIdProducto(Long idProducto);
    List<Movimiento> findByFechaBetween(LocalDateTime inicio, LocalDateTime fin);
    List<Movimiento> findByFechaBetweenAndTipo(LocalDateTime inicio, LocalDateTime fin, TipoMovimiento tipoMovimiento);
    List<Movimiento> findByFechaBetweenAndMotivo(LocalDateTime inicio, LocalDateTime fin, MotivoMovimiento motivo);
    List<Movimiento> findByFechaBetweenAndTipoAndMotivo(LocalDateTime inicio, LocalDateTime fin, TipoMovimiento tipo, MotivoMovimiento motivo);
    boolean existsByProducto_IdProducto(Long idProducto);


}