package com.app.royal.royal.controlador;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

@Controller
public class DashboardController {

    @GetMapping("/dashboard")
    public String dashboard() {
        return "dashboard";
    }

    @GetMapping("/admin/exportar-bd")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<InputStreamResource> exportarBaseDatos() throws IOException, IOException {
        String nombreArchivo = "respaldo_bd.sql";
        ProcessBuilder pb = new ProcessBuilder(
                "mysqldump",
                "-u", "administrador",
                "-pqwerty124",  // ⚠️ reemplaza con tu contraseña
                "bd_royal"        // ⚠️ reemplaza con el nombre real de tu base
        );
        pb.redirectOutput(new File(nombreArchivo));
        Process proceso = pb.start();

        try {
            if (proceso.waitFor() == 0) {
                InputStreamResource resource = new InputStreamResource(new FileInputStream(nombreArchivo));
                return ResponseEntity.ok()
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + nombreArchivo)
                        .contentType(MediaType.APPLICATION_OCTET_STREAM)
                        .body(resource);
            } else {
                return ResponseEntity.status(500).body(null);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return ResponseEntity.status(500).body(null);
        }
    }

    @PostMapping("/admin/importar-bd")
    @PreAuthorize("hasRole('ADMIN')")
    public String importarBaseDatos(@RequestParam("archivoSql") MultipartFile archivo) {
        if (archivo.isEmpty()) {
            return "redirect:/dashboard?error=vacio";
        }

        try {
            // Guardar el archivo en un archivo temporal
            File archivoTemp = File.createTempFile("import_", ".sql");
            archivo.transferTo(archivoTemp);
            System.out.println("Archivo recibido: " + archivoTemp.getAbsolutePath());

            ProcessBuilder pb = new ProcessBuilder(
                    "mysql",
                    "-u", "administrador",
                    "-pqwerty124",   // ⚠️ reemplaza con tu contraseña
                    "bd_royal"
            );
            pb.redirectInput(archivoTemp);
            Process proceso = pb.start();

            if (proceso.waitFor() == 0) {
                return "redirect:/dashboard?importado=ok";
            } else {
                return "redirect:/dashboard?error=fallo";
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "redirect:/dashboard?error=excepcion";
        }
    }

}

