package com.app.royal.royal.controlador;

import com.app.royal.royal.entidades.Producto;
import com.app.royal.royal.entidades.Categoria;
import com.app.royal.royal.repositorios.CategoriaRepository;
import com.app.royal.royal.repositorios.MovimientoRepository;
import com.app.royal.royal.repositorios.ProductoRepository;
import com.app.royal.royal.servicios.ProductoService;
import com.app.royal.royal.servicios.CategoriaService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.ByteArrayInputStream;
import java.util.List;

@Controller
public class ProductoViewController {

    private final ProductoService productoService;
    private final CategoriaService categoriaService;
    @Autowired
    private MovimientoRepository movimientoRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private CategoriaRepository categoriaRepository;


    public ProductoViewController(ProductoService productoService, CategoriaService categoriaService) {
        this.productoService = productoService;
        this.categoriaService = categoriaService;
    }

    @GetMapping("/productos")
    public String verProductos(Model model) {
        model.addAttribute("productos", productoService.listarTodos());
        model.addAttribute("categorias", categoriaService.listarTodas());
        model.addAttribute("producto", new Producto()); // Para formulario vacío
        return "productos";
    }

    @GetMapping("/productosEmpleado")
    public String productosEmpleado(Model model) {
        // Lógica para obtener productos para el empleado
        List<Producto> productos = productoService.listarTodos();
        model.addAttribute("productos", productos);
        return "productosEmpleado"; // Asegúrate que el nombre coincide con el archivo .html
    }

    @GetMapping("/productos/editar/{id}")
    public String editarProducto(@PathVariable Long id, Model model) {
        Producto producto = productoService.obtenerPorId(id);
        model.addAttribute("producto", producto);
        model.addAttribute("categorias", categoriaService.listarTodas());
        model.addAttribute("productos", productoService.listarTodos());
        return "productos";
    }

    @PostMapping("/productos/actualizar")
    public String actualizarProducto(@ModelAttribute Producto producto) {
        productoService.guardar(producto); // El mismo método sirve para update
        return "redirect:/productos";
    }

    @GetMapping("/productos/eliminar/{id}")
    public String eliminarProducto(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        if (movimientoRepository.existsByProducto_IdProducto(id)) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar el producto porque tiene movimientos asociados.");
            return "redirect:/productos";
        }

        productoRepository.deleteById(id);
        redirectAttributes.addFlashAttribute("success", "Producto eliminado correctamente.");
        return "redirect:/productos";
    }



    @PostMapping("/productos")
    public String guardarProducto(@ModelAttribute Producto producto) {
        productoService.guardar(producto);
        return "redirect:/productos";
    }

    @GetMapping("/productos/alerta-stock")
    public String verAlertaStock(Model model) {
        List<Producto> productosCriticos = productoService.obtenerProductosConStockBajo();
        model.addAttribute("productosCriticos", productosCriticos);
        return "alerta_stock";
    }

    @GetMapping("/productos/exportar/pdf")
    public ResponseEntity<byte[]> exportarProductosPdf() {
        ByteArrayInputStream stream = productoService.generarReportePDF();
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "inline; filename=productos.pdf");
        return ResponseEntity.ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(stream.readAllBytes());
    }

    @GetMapping("/productos/exportar/excel")
    public ResponseEntity<byte[]> exportarProductosExcel() {
        ByteArrayInputStream stream = productoService.generarReporteExcel();
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=productos.xlsx");
        return ResponseEntity.ok()
                .headers(headers)
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(stream.readAllBytes());
    }

    @GetMapping("/productos/buscar")
    public String buscarPorNombre(@RequestParam("nombre") String nombre, Model model) {
        List<Producto> productos = productoRepository.findByNombreContainingIgnoreCase(nombre);
        model.addAttribute("productos", productos);
        model.addAttribute("producto", new Producto());
        model.addAttribute("categorias", categoriaRepository.findAll());
        return "productos"; // o el nombre exacto de tu vista
    }


}

