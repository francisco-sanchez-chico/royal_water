package com.app.royal.royal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoyalApplicationTests {

    @Test
    void contextLoads() {
    }

}
