package com.app.royal.royal.controlador;

import com.app.royal.royal.entidades.Defecto;
import com.app.royal.royal.entidades.Producto;
import com.app.royal.royal.repositorios.DefectoRepository;
import com.app.royal.royal.repositorios.ProductoRepository;
import com.app.royal.royal.servicios.DefectoService;
import com.app.royal.royal.servicios.ProductoService;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

@Controller
@RequestMapping("/defectos")
public class DefectoController {

    private final DefectoService defectoService;
    private final ProductoService productoService;

    @Autowired
    private final DefectoRepository defectoRepository;

    @Autowired
    private final ProductoRepository productoRepository;

    public DefectoController(DefectoService defectoService, ProductoService productoService, DefectoRepository defectoRepository, ProductoRepository productoRepository) {
        this.defectoService = defectoService;
        this.productoService = productoService;
        this.defectoRepository = defectoRepository;
        this.productoRepository = productoRepository;
    }

    @GetMapping
    public String mostrarFormulario(Model model) {
        model.addAttribute("defecto", new Defecto());
        model.addAttribute("productos", productoService.listarTodos());
        model.addAttribute("defectos", defectoService.listarTodos());
        return "defectos"; // la vista Thymeleaf que debes tener: templates/defectos.html
    }

    @PostMapping
    public String registrar(@ModelAttribute Defecto defecto,
                            RedirectAttributes redirectAttributes) {
        try {
            Optional<Producto> optionalProducto = productoService.buscarPorId(defecto.getProducto().getIdProducto());

            if (optionalProducto.isEmpty()) {
                redirectAttributes.addFlashAttribute("error", "El producto no existe.");
                return "redirect:/defectos";
            }

            Producto producto = optionalProducto.get();

            if (producto.getCantidadActual() <= 0) {
                redirectAttributes.addFlashAttribute("error", "No hay stock disponible.");
                return "redirect:/defectos";
            }

            if (defecto.getCantidadAfectada() > producto.getCantidadActual()) {
                redirectAttributes.addFlashAttribute("error", "Cantidad afectada mayor al stock.");
                return "redirect:/defectos";
            }

            defectoService.registrar(defecto);
            redirectAttributes.addFlashAttribute("exito", "Defecto registrado correctamente.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al registrar: " + e.getMessage());
        }

        return "redirect:/defectos";
    }

    @GetMapping("/exportar")
    public ResponseEntity<?> exportarDefectos(
            @RequestParam("formato") String formato,
            @RequestParam("fechaInicio") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fechaInicio,
            @RequestParam("fechaFin") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fechaFin) {

        if ("pdf".equalsIgnoreCase(formato)) {
            byte[] pdf = generarPdfConDefectos(fechaInicio, fechaFin);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=defectos.pdf")
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(pdf);
        } else if ("excel".equalsIgnoreCase(formato)) {
            byte[] excel = generarExcelConDefectos(fechaInicio, fechaFin);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=defectos.xlsx")
                    .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .body(excel);
        } else {
            return ResponseEntity.badRequest().body("Formato no válido. Usa 'pdf' o 'excel'.");
        }
    }

    private byte[] generarPdfConDefectos(LocalDate fechaInicio, LocalDate fechaFin) {
        List<Defecto> defectos = defectoService.buscarPorRangoFechas(fechaInicio, fechaFin);

        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            Document document = new Document();
            PdfWriter.getInstance(document, outputStream);
            document.open();

            // Ruta del logo (ajústala según tu estructura de proyecto)
            String logoPath = "src/main/resources/static/logo.png";
            Image logo = Image.getInstance(logoPath);
            logo.scaleToFit(80, 80);
            logo.setAlignment(Image.LEFT);
            document.add(logo);

            // Título
            Paragraph titulo = new Paragraph("Reporte de Defectos", new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD));
            titulo.setAlignment(Element.ALIGN_CENTER);
            document.add(titulo);

            // Rango de fechas
            Paragraph rangoFechas = new Paragraph("Desde: " + fechaInicio + "  Hasta: " + fechaFin);
            rangoFechas.setAlignment(Element.ALIGN_CENTER);
            document.add(rangoFechas);

            document.add(new Paragraph("\n")); // Espacio

            // Tabla
            PdfPTable table = new PdfPTable(5); // 5 columnas (sin ID)
            table.setWidthPercentage(100);
            table.setWidths(new float[]{2, 3, 1.5f, 2, 2});

            // Encabezados
            Stream.of("Producto", "Descripción", "Cantidad", "Fecha", "Tipo")
                    .forEach(header -> {
                        PdfPCell cell = new PdfPCell(new Phrase(header));
                        cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
                        table.addCell(cell);
                    });

            for (Defecto defecto : defectos) {
                table.addCell(defecto.getProducto().getNombre());
                table.addCell(defecto.getDescripcion());
                table.addCell(String.valueOf(defecto.getCantidadAfectada()));
                table.addCell(String.valueOf(defecto.getFechaRegistro()));
                table.addCell(defecto.getTipo().name());
            }

            document.add(table);
            document.close();

            return outputStream.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
            return new byte[0];
        }
    }


    private byte[] generarExcelConDefectos(LocalDate fechaInicio, LocalDate fechaFin) {
        List<Defecto> defectos = defectoService.buscarPorRangoFechas(fechaInicio, fechaFin);

        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Defectos");

            // Encabezados sin el ID
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Producto");
            header.createCell(1).setCellValue("Descripción");
            header.createCell(2).setCellValue("Cantidad Afectada");
            header.createCell(3).setCellValue("Fecha");
            header.createCell(4).setCellValue("Tipo de Defecto");

            int rowNum = 1;
            for (Defecto defecto : defectos) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(defecto.getProducto().getNombre());
                row.createCell(1).setCellValue(defecto.getDescripcion());
                row.createCell(2).setCellValue(defecto.getCantidadAfectada());
                row.createCell(3).setCellValue(defecto.getFechaRegistro().toString());
                row.createCell(4).setCellValue(defecto.getTipo().name());
            }

            // Ajustar ancho de columnas
            for (int i = 0; i < 5; i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(outputStream);
            return outputStream.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            return new byte[0];
        }
    }

    @GetMapping("/buscar")
    public String buscarPorProducto(@RequestParam("productoId") Long productoId, Model model) {
        List<Defecto> defectos = defectoRepository.findByProductoIdProducto(productoId);
        List<Producto> productos = productoRepository.findAll();
        model.addAttribute("defectos", defectos);
        model.addAttribute("productos", productos);
        model.addAttribute("defecto", new Defecto());
        return "defectos"; // o el nombre exacto de tu plantilla HTML
    }

}
