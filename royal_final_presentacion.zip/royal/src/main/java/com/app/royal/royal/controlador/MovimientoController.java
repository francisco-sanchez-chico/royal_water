package com.app.royal.royal.controlador;

import com.app.royal.royal.entidades.*;
import com.app.royal.royal.repositorios.MovimientoRepository;
import com.app.royal.royal.repositorios.ProductoRepository;
import com.app.royal.royal.servicios.MovimientoService;
import com.app.royal.royal.servicios.ProductoService;
import com.app.royal.royal.servicios.UsuarioService;
import com.itextpdf.text.DocumentException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/movimientos")
public class MovimientoController {

    private final MovimientoService movimientoService;
    private final ProductoService productoService;
    private final UsuarioService usuarioService;

    @Autowired
    private final MovimientoRepository movimientoRepository;

    @Autowired
    private final ProductoRepository productoRepository;

    public MovimientoController(MovimientoService movimientoService, ProductoService productoService, UsuarioService usuarioService, MovimientoRepository movimientoRepository, ProductoRepository productoRepository) {
        this.movimientoService = movimientoService;
        this.productoService = productoService;
        this.usuarioService = usuarioService;
        this.movimientoRepository = movimientoRepository;
        this.productoRepository = productoRepository;
    }

    @GetMapping
    public String vistaMovimientos(Model model) {
        model.addAttribute("movimientos", movimientoService.listarTodos());
        model.addAttribute("productos", productoService.listarTodos());
        model.addAttribute("usuarios", usuarioService.listarTodos());
        model.addAttribute("motivos", MotivoMovimiento.values());
        return "movimientos";
    }

    @GetMapping("/empleados")
    public String vistaMovimientosEmpleado(Model model) {
        model.addAttribute("movimientos", movimientoService.listarTodos());
        model.addAttribute("productos", productoService.listarTodos());
        model.addAttribute("usuarios", usuarioService.listarTodos());
        model.addAttribute("motivos", MotivoMovimiento.values());
        return "movimientosEmpleado";
    }

    @PostMapping("/guardar")
    public String registrarMovimiento(@ModelAttribute Movimiento movimiento) {
        // Obtener el usuario actual desde Spring Security
        String username = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUsername();

        // Buscar al usuario en la base de datos
        Usuario usuario = usuarioService.buscarPorUsername(username)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado en el sistema"));

        // Asignar el usuario al movimiento
        movimiento.setUsuario(usuario);

        // Asignar la fecha actual si no se proporciona una
        if (movimiento.getFecha() == null) {
            movimiento.setFecha(LocalDateTime.now());
        }

        // Guardar el movimiento
        movimientoService.guardar(movimiento);
        return "redirect:/movimientos";
    }

    // Filtrar por fecha y mostrar en página
    @GetMapping("/filtrar")
    public String filtrarPorFechas(
            @RequestParam("desde") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam("hasta") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta,
            Model model) {
        List<Movimiento> resultado = movimientoService.buscarPorRangoFechas(desde, hasta);
        model.addAttribute("movimientos", resultado);
        model.addAttribute("desde", desde);
        model.addAttribute("hasta", hasta);
        return "movimientos"; // Reutiliza misma vista
    }

    @GetMapping("/exportar")
    public ResponseEntity<byte[]> exportarMovimientos(
            @RequestParam("fechaInicio") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicio,
            @RequestParam("fechaFin") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaFin,
            @RequestParam(name = "tipoMovimiento", required = false, defaultValue = "todos") String tipoMovimiento,
            @RequestParam(name = "motivoMovimiento", required = false, defaultValue = "todos") String motivoMovimiento,
            @RequestParam("formato") String formato) throws Exception {

        LocalDateTime inicio = fechaInicio.atStartOfDay();
        LocalDateTime fin = fechaFin.atTime(23, 59, 59);

        TipoMovimiento tipo = "todos".equalsIgnoreCase(tipoMovimiento) ? null : TipoMovimiento.valueOf(tipoMovimiento);
        MotivoMovimiento motivo = "todos".equalsIgnoreCase(motivoMovimiento) ? null : MotivoMovimiento.valueOf(motivoMovimiento);

        // Buscar movimientos según los filtros aplicados
        List<Movimiento> movimientos = movimientoService.buscarPorRangoTipoYMotivo(inicio, fin, tipo, motivo);

        if (formato.equalsIgnoreCase("pdf")) {
            byte[] pdf = movimientoService.generarReportePdf(movimientos, fechaInicio, fechaFin, tipoMovimiento, String.valueOf(motivo));
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=movimientos.pdf")
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(pdf);
        } else {
            byte[] excel = movimientoService.generarReporteExcel(movimientos);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=movimientos.xlsx")
                    .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .body(excel);
        }
    }

    @GetMapping("/buscar")
    public String buscarPorProducto(@RequestParam("productoId") Long productoId, Model model) {
        List<Movimiento> movimientos = movimientoRepository.findByProductoIdProducto(productoId);
        List<Producto> productos = productoRepository.findAll();
        model.addAttribute("movimientos", movimientos);
        model.addAttribute("productos", productos);
        model.addAttribute("motivos", MotivoMovimiento.values()); // Si usas enum Motivo
        return "movimientos"; // nombre de tu vista Thymeleaf
    }



}
