package com.app.royal.royal.controlador;

import com.app.royal.royal.entidades.Defecto;
import com.app.royal.royal.entidades.Producto;
import com.app.royal.royal.servicios.DefectoService;
import com.app.royal.royal.servicios.ProductoService;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/defectosssss")
public class DefectoWebController {

    /*private final DefectoService defectoService;
    private final ProductoService productoService;

    public DefectoWebController(DefectoService defectoService, ProductoService productoService) {
        this.defectoService = defectoService;
        this.productoService = productoService;
    }

    @GetMapping
    public String mostrarFormulario(Model model) {
        model.addAttribute("defecto", new Defecto());
        model.addAttribute("productos", productoService.listarTodos());
        model.addAttribute("defectos", defectoService.listarTodos());
        return "defectos"; // la vista Thymeleaf que debes tener: templates/defectos.html
    }

    @PostMapping
    public String registrar(@ModelAttribute Defecto defecto,
                            RedirectAttributes redirectAttributes) {
        try {
            Optional<Producto> optionalProducto = productoService.buscarPorId(defecto.getProducto().getIdProducto());

            if (optionalProducto.isEmpty()) {
                redirectAttributes.addFlashAttribute("error", "El producto no existe.");
                return "redirect:/defectos";
            }

            Producto producto = optionalProducto.get();

            if (producto.getCantidadActual() <= 0) {
                redirectAttributes.addFlashAttribute("error", "No hay stock disponible.");
                return "redirect:/defectos";
            }

            if (defecto.getCantidadAfectada() > producto.getCantidadActual()) {
                redirectAttributes.addFlashAttribute("error", "Cantidad afectada mayor al stock.");
                return "redirect:/defectos";
            }

            defectoService.registrar(defecto);
            redirectAttributes.addFlashAttribute("exito", "Defecto registrado correctamente.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al registrar: " + e.getMessage());
        }

        return "redirect:/defectos";
    }

    @GetMapping("/exportar")
    public ResponseEntity<?> exportarDefectos(
            @RequestParam("formato") String formato,
            @RequestParam("fechaInicio") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fechaInicio,
            @RequestParam("fechaFin") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fechaFin) {

        if ("pdf".equalsIgnoreCase(formato)) {
            byte[] pdf = generarPdfConDefectos(fechaInicio, fechaFin);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=defectos.pdf")
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(pdf);
        } else if ("excel".equalsIgnoreCase(formato)) {
            byte[] excel = generarExcelConDefectos(fechaInicio, fechaFin);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=defectos.xlsx")
                    .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .body(excel);
        } else {
            return ResponseEntity.badRequest().body("Formato no válido. Usa 'pdf' o 'excel'.");
        }
    }

    private byte[] generarPdfConDefectos(LocalDate fechaInicio, LocalDate fechaFin) {
        List<Defecto> defectos = defectoService.buscarPorRangoFechas(fechaInicio, fechaFin);

        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            Document document = new Document();
            PdfWriter.getInstance(document, outputStream);
            document.open();
            document.add(new Paragraph("Reporte de Defectos desde " + fechaInicio + " hasta " + fechaFin));
            for (Defecto defecto : defectos) {
                document.add(new Paragraph(defecto.getDescripcion() + " - Cantidad: " + defecto.getCantidadAfectada()));
            }
            document.close();
            return outputStream.toByteArray();
        } catch (DocumentException | IOException e) {
            e.printStackTrace();
            return new byte[0];
        }
    }

    private byte[] generarExcelConDefectos(LocalDate fechaInicio, LocalDate fechaFin) {
        List<Defecto> defectos = defectoService.buscarPorRangoFechas(fechaInicio, fechaFin);

        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Defectos");
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("ID");
            header.createCell(1).setCellValue("Descripción");
            header.createCell(2).setCellValue("Cantidad");

            int rowNum = 1;
            for (Defecto defecto : defectos) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(defecto.getIdDefecto());
                row.createCell(1).setCellValue(defecto.getDescripcion());
                row.createCell(2).setCellValue(defecto.getCantidadAfectada());
            }

            workbook.write(outputStream);
            return outputStream.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            return new byte[0];
        }
    }*/
}
