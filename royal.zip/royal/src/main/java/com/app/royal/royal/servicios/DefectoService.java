package com.app.royal.royal.servicios;

import com.app.royal.royal.entidades.Defecto;
import com.app.royal.royal.entidades.Producto;
import com.app.royal.royal.repositorios.DefectoRepository;
import com.app.royal.royal.repositorios.ProductoRepository;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Stream;

@Service
public class DefectoService {

    private final DefectoRepository defectoRepository;
    private final ProductoRepository productoRepository;

    public DefectoService(DefectoRepository defectoRepository, ProductoRepository productoRepository) {
        this.defectoRepository = defectoRepository;
        this.productoRepository = productoRepository;
    }

    public Defecto registrar(Defecto defecto) {
        Producto producto = productoRepository.findById(defecto.getProducto().getIdProducto())
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));

        if (producto.getCantidadActual() <= 0) {
            throw new RuntimeException("El producto no tiene stock disponible.");
        }

        if (producto.getCantidadActual() < defecto.getCantidadAfectada()) {
            throw new RuntimeException("La cantidad afectada supera el inventario disponible.");
        }

        producto.setCantidadActual(producto.getCantidadActual() - defecto.getCantidadAfectada());
        productoRepository.save(producto);

        return defectoRepository.save(defecto);
    }


    public List<Defecto> listarTodos() {
        return defectoRepository.findAll();
    }

    public void eliminar(Long id) {
        defectoRepository.deleteById(id);
    }


    public List<Defecto> buscarPorProducto(Long idProducto) {
        return defectoRepository.findByProductoIdProducto(idProducto);
    }

    public List<Defecto> buscarPorRangoFechas(LocalDate desde, LocalDate hasta) {
        LocalDateTime desdeInicio = desde.atStartOfDay();
        LocalDateTime hastaFin = hasta.atTime(23, 59, 59);
        return defectoRepository.findAll().stream()
                .filter(d -> d.getFechaRegistro().atStartOfDay().isAfter(desdeInicio.minusSeconds(1)) &&
                        d.getFechaRegistro().atStartOfDay().isBefore(hastaFin.plusSeconds(1)))
                .toList();
    }

}

