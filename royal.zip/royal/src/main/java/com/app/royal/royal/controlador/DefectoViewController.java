package com.app.royal.royal.controlador;

import com.app.royal.royal.entidades.Defecto;
import com.app.royal.royal.servicios.DefectoService;
import com.app.royal.royal.servicios.ProductoService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Controller
@RequestMapping("/defectosss4")
public class DefectoViewController {
    /*
    private final DefectoService defectoService;
    private final ProductoService productoService;


    public DefectoViewController(DefectoService defectoService, ProductoService productoService) {
        this.defectoService = defectoService;
        this.productoService = productoService;
    }

    @GetMapping
    public String mostrarDefectos(Model model,
                                  @RequestParam(value = "desde", required = false) LocalDate desde,
                                  @RequestParam(value = "hasta", required = false) LocalDate hasta) {

        List<Defecto> defectos;
        if (desde != null && hasta != null) {
            defectos = defectoService.buscarPorRangoFechas(desde, hasta);
        } else {
            defectos = defectoService.listarTodos();
        }

        model.addAttribute("defectos", defectos);
        model.addAttribute("productos", productoService.listarTodos());
        model.addAttribute("defecto", new Defecto()); // Para el formulario de registro
        return "defectos";
    }

    @PostMapping("/registrar")
    public String registrarDefecto(@ModelAttribute("defecto") @Valid Defecto defecto,
                                   BindingResult result,
                                   Model model,
                                   RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            model.addAttribute("productos", productoService.listarTodos());
            model.addAttribute("defectos", defectoService.listarTodos());
            return "defectos";
        }

        try {
            defectoService.registrar(defecto);
            redirectAttributes.addFlashAttribute("exito", "Defecto registrado correctamente.");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/defectos";
    }*/
}
