-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: bd_royal
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categoria`
--

DROP TABLE IF EXISTS `categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoria` (
  `id_categoria` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria`
--

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES (1,'Garrafones de agua','Garrafon'),(5,'Agua embotellada','Botellas de agua'),(6,'Bolsas de hielo','Hielo');
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `defecto`
--

DROP TABLE IF EXISTS `defecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `defecto` (
  `id_defecto` bigint NOT NULL AUTO_INCREMENT,
  `cantidad_afectada` int DEFAULT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `fecha_registro` date DEFAULT NULL,
  `tipo` enum('CADUCADO','DANO_FISICO','FUGA','MAL_ESTADO') DEFAULT NULL,
  `id_producto` bigint NOT NULL,
  `tipo_defecto` enum('CADUCADO','DANO_FISICO','FUGA','MAL_ESTADO') NOT NULL,
  PRIMARY KEY (`id_defecto`),
  KEY `FKbr9550dp8x10u4wx4nph9gr15` (`id_producto`),
  CONSTRAINT `FKbr9550dp8x10u4wx4nph9gr15` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `defecto`
--

LOCK TABLES `defecto` WRITE;
/*!40000 ALTER TABLE `defecto` DISABLE KEYS */;
INSERT INTO `defecto` VALUES (1,1,'Garrafón con un golpe que daño el plastico.','2025-04-28','DANO_FISICO',9,'CADUCADO'),(2,5,'Se paso de la fecha de caducidad','2025-05-05','CADUCADO',9,'CADUCADO'),(3,1,'golpe','2025-05-05','DANO_FISICO',9,'CADUCADO'),(4,3,'golpe','2025-05-05','DANO_FISICO',9,'CADUCADO'),(5,1,'golpe','2025-05-06',NULL,9,'DANO_FISICO'),(6,1,'Tiene una pequeña grieta','2025-05-06',NULL,13,'FUGA');
/*!40000 ALTER TABLE `defecto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimiento`
--

DROP TABLE IF EXISTS `movimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movimiento` (
  `id_movimiento` bigint NOT NULL AUTO_INCREMENT,
  `cantidad` int NOT NULL,
  `fecha` datetime(6) NOT NULL,
  `motivo` enum('DEVOLUCION','REABASTECIMIENTO','VENTA') NOT NULL,
  `tipo` enum('ENTRADA','SALIDA') NOT NULL,
  `id_producto` bigint NOT NULL,
  `id_usuario` bigint NOT NULL,
  PRIMARY KEY (`id_movimiento`),
  KEY `FK63n56shb2x7n84xl8syjt9k6m` (`id_producto`),
  KEY `FK9la21hyiledt7gvh51fj604p2` (`id_usuario`),
  CONSTRAINT `FK63n56shb2x7n84xl8syjt9k6m` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`),
  CONSTRAINT `FK9la21hyiledt7gvh51fj604p2` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `movimiento_chk_1` CHECK ((`cantidad` >= 1))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimiento`
--

LOCK TABLES `movimiento` WRITE;
/*!40000 ALTER TABLE `movimiento` DISABLE KEYS */;
INSERT INTO `movimiento` VALUES (1,1,'2025-05-07 03:31:06.611145','DEVOLUCION','SALIDA',9,3),(2,1,'2025-05-07 04:29:44.221488','REABASTECIMIENTO','ENTRADA',9,3),(3,4,'2025-05-07 05:11:28.814820','VENTA','SALIDA',9,3),(4,1,'2025-05-07 05:13:40.575575','REABASTECIMIENTO','ENTRADA',13,3),(5,2,'2025-05-07 05:14:05.011009','VENTA','SALIDA',13,3);
/*!40000 ALTER TABLE `movimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto`
--

DROP TABLE IF EXISTS `producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `producto` (
  `id_producto` bigint NOT NULL AUTO_INCREMENT,
  `cantidad_actual` int DEFAULT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `fecha_ingreso` date DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `id_categoria` bigint NOT NULL,
  `stock_minimo` int NOT NULL,
  PRIMARY KEY (`id_producto`),
  KEY `FK9nyueixdsgbycfhf7allg8su` (`id_categoria`),
  CONSTRAINT `FK9nyueixdsgbycfhf7allg8su` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`),
  CONSTRAINT `producto_chk_1` CHECK ((`stock_minimo` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto`
--

LOCK TABLES `producto` WRITE;
/*!40000 ALTER TABLE `producto` DISABLE KEYS */;
INSERT INTO `producto` VALUES (9,3,'Garrafón de agua purificada','2025-05-06','Garrafón 19.5L',1,10),(13,8,'Garrafon de agua de 20lt','2025-05-06','Garrafon 20lt',1,5);
/*!40000 ALTER TABLE `producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `id_usuario` bigint NOT NULL AUTO_INCREMENT,
  `apellido` varchar(255) DEFAULT NULL,
  `correo` varchar(255) DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `rol` enum('ADMINISTRADOR','EMPLEADO') DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `UK863n1y3x0jalatoir4325ehal` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (3,'López','carlos@royalwater.com','Carlos','$2a$10$MWqoG9q2o34L0zA8l/hcfurxM2tcpmi97LKRcmbEUdrW05oo9TpJu','ADMINISTRADOR','4'),(5,'López','carlos@royalwater.com','Carlos','$2a$10$mjE9MHDBlnzzK1R6P3kSXuJkIvZ/tpdjCBP.I1XIjt/P5ZCpP1HsS','EMPLEADO','41'),(6,'b','c@gmail.com','a','$2a$10$Yv.zB1tu4DUjc5DN3fwUSu6sL6Th8l4jWte539fFhOwTET.6DEQSe','EMPLEADO','admin');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-06 22:18:03
